﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime;

enum Operation
{
    Plus,
    Minus,
    Multiply
}

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        int lives = 3, balls = 0;
        Operation op;
        Random rand = new Random();
        Timer timer = new Timer();
        public Form1()
        {
            InitializeComponent();
            randomAnswer();
            timer.Tick += UpdateTime;
            timer.Interval = 1000;
            timer.Start();
        }

        private void IsGameOver()
        {
            if (lives <= 0)
            {
                timer.Stop();
                DialogResult dr = MessageBox.Show($"Score: {balls}\nPlay Again?", "Game Over!", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
                if (dr == DialogResult.Yes)
                {
                    lives = 3;
                    label4.Text = lives.ToString();
                    balls = 0;
                    label2.Text = balls.ToString();
                    label6.Text = "10";
                    textBox1.Text = "";
                    timer.Start();
                }
                else { System.Environment.Exit(0); }        
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (lives > 0 && textBox1.Text != String.Empty)
            {
                int answer = int.Parse(textBox1.Text);
                int numOne = int.Parse(label7.Text), numTwo = int.Parse(label9.Text);
        
                if ((op == Operation.Plus && (numOne + numTwo == answer)) ||
                    (op == Operation.Minus && (numOne - numTwo == answer)) ||
                    (op == Operation.Multiply && (numOne * numTwo == answer)))
                {
                    balls++;
                    label2.Text = balls.ToString();

                }
                else
                {
                    lives--;
                    IsGameOver();
                    label4.Text = lives.ToString();
                }
                label6.Text = "10";
                textBox1.Text = String.Empty;
                randomAnswer();
            }
        }

        private void UpdateTime(object sender, EventArgs e)
        {
            int time = int.Parse(label6.Text);
            if (time <= 0)
            {
                lives--;
                IsGameOver();
                label4.Text = lives.ToString();
                label6.Text = "10";
                randomAnswer();
            }
            else
            {
                time--;
                label6.Text = time.ToString();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void randomAnswer()
        {
            label7.Text = rand.Next(0, 101).ToString();
            label9.Text = rand.Next(0, 101).ToString();
            int oper = rand.Next(0, 3);
            switch (oper)
            {
                case 0:
                    op = Operation.Plus;
                    label8.Text = "+";
                    break;
                case 1:
                    op = Operation.Minus;
                    label8.Text = "-";
                    break;
                default:
                    op = Operation.Multiply;
                    label8.Text = "*";
                    break;
            }
        }
    }
}
